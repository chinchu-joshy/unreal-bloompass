import { useEffect, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass";
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass.js";
import { SMAAPass } from "three/examples/jsm/postprocessing/SMAAPass";
import { FXAAShader } from "three/examples/jsm/shaders/FXAAShader";
import vertex from "./VertexShader";
import fragment from "./FragmentShader";
import Animations from "./Animations";
import * as TWEEN from "@tweenjs/tween.js";
function Scene() {
  let torusArray = [];

  useEffect(() => {
    let materials = {};
    let unrealbloompass;
    /* --------------------------- Creating the scene --------------------------- */
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);
    /* ---------------------- creating canvas and renderer ---------------------- */
    const canvas = document.querySelector(".canvas");
    const renderer = new THREE.WebGL1Renderer({
      canvas,
      antialias: true,
      stencil: false,
      depth: false,
    });
    renderer.setSize(canvas.offsetWidth, canvas.offsetHeight);
    /* ----------------------------- create material ---------------------------- */
    const darkMaterial = new THREE.MeshBasicMaterial({ color: "black" });
    const material = new THREE.MeshStandardMaterial({
      emissive: 0xffffff,
      emissiveIntensity: 1,
      color: 0xffffff,
    });
    /* ------------------------------- add camera ------------------------------- */
    const camera = new THREE.PerspectiveCamera(
      45,
      canvas.offsetWidth / canvas.offsetHeight,
      1,
      10000
    );
    camera.position.set(-100, 60, 700);
    camera.lookAt(0, 0, 0);
    /* ---------------- create plane geometry and adding texture ---------------- */
    const geometry = new THREE.PlaneGeometry(5000, 5000);
    const texture = new THREE.TextureLoader();
    texture.load(
      "./Texture/ground.jpg",

      function (texture) {
        const material = new THREE.MeshPhongMaterial({
          map: texture,
        // color:0x152238,
          side: THREE.DoubleSide,
          reflectivity: 1,
          refractionRatio: .5,
          shininess: 66.9,
          specular: 895252,
        });

        material.needsUpdate = true;

        const plane = new THREE.Mesh(geometry, material);
        plane.rotateX(-Math.PI / 2);
        plane.receiveShadow=true
        scene.add(plane);
      },

      undefined,

      function (err) {
        console.error("An error happened.", err);
      }
    );
    /* ------------------------ adding light to the scene ----------------------- */
    const light = new THREE.AmbientLight(0xffffff, 0.5); // soft white light
    scene.add(light);
    const directionalLight = new THREE.DirectionalLight( 0xffffff, 0.2 );
    directionalLight.castShadow=true
scene.add( directionalLight );
    /* -------------------------- adding torus geometry ------------------------- */
    const torusgeometry = new THREE.TorusGeometry(200, 4, 30, 200, Math.PI);
    const animationGroup = new THREE.AnimationObjectGroup();
    material.needsUpdate = true;
    const torus = new THREE.Mesh(torusgeometry, material);
    torus.userData.material = "bloom";
    torus.position.z = 700;
    // torusArray.push(torus);
    // animationGroup.add(torus);

    function generateTorus(i) {
      const newTorus = torus.clone();
      newTorus.castShadow=true
      newTorus.position.set(0, 0, torus.position.z - i * 230);

      torusArray.push(newTorus);
      animationGroup.add(newTorus);
      //   scene.add(newTorus);

      if (i < 11) {
        generateTorus(i + 1);
      } else {
        return;
      }
    }
    generateTorus(0);
    let i = torusArray.length - 1;
    setInterval(() => {
      if (i > 0) {
        scene.add(torusArray[i]);
      } else {
        return;
      }

      i--;
    }, 80);
    /* ---------------------------- post proccessing ---------------------------- */
   
    const composer = new EffectComposer(renderer);
    composer.renderToScreen = false;
    composer.renderTarget1.texture.encoding = THREE.sRGBEncoding;
    composer.renderTarget2.texture.encoding = THREE.sRGBEncoding;
    composer.addPass(new RenderPass(scene, camera));

    unrealbloompass = new UnrealBloomPass({ x: 1024, y: 1024 }, 0.7, 0, 0.75);
    console.log(unrealbloompass.strength);
    composer.addPass(unrealbloompass);
    function darkenNonBloomed(obj) {
      if (obj.isMesh && obj.userData.material !== "bloom") {
        materials[obj.uuid] = obj.material;
        obj.material = darkMaterial;
      }
    }
    function restoreMaterial(obj) {
      if (materials[obj.uuid]) {
        obj.material = materials[obj.uuid];
        delete materials[obj.uuid];
      }
    }

    const finalPass = new ShaderPass(
      new THREE.ShaderMaterial({
        uniforms: {
          baseTexture: { value: null },
          bloomTexture: { value: composer.renderTarget2.texture },
        },
        vertexShader: vertex,
        fragmentShader: fragment,
        defines: {},
      }),
      "baseTexture"
    );

    finalPass.needsSwap = true;
    let pixelRatio = renderer.getPixelRatio();
    const finalComposer = new EffectComposer(renderer);
    const effectFXAA = new ShaderPass(FXAAShader);
    effectFXAA.uniforms["resolution"].value.x =
      1 / (canvas.offsetWidth * pixelRatio);
    effectFXAA.uniforms["resolution"].value.y =
      1 / (canvas.offsetHeight * pixelRatio);
      const pass = new SMAAPass(window.innerWidth * renderer.getPixelRatio(),window.innerHeight * renderer.getPixelRatio() );
				composer.addPass( pass );
    //finalComposer.addPass(pass);
    finalComposer.addPass(new RenderPass(scene, camera));
    finalComposer.addPass(finalPass);
    /* ----------------------------- adding animation ---------------------------- */
    console.log(light.intensity);
    let colorKF;

    colorKF = new THREE.ColorKeyframeTrack(
      ".material.color",
      [0, 1, 2, 3],
      [1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1],
      THREE.LinearInterpolant
    );

    const opacityKF = new THREE.NumberKeyframeTrack(
      ".material.emissiveIntensity",
      [0, 1, 2, 3],
      [1, 0.8, 0.8, 1]
    );
    const clip = new THREE.AnimationClip("default", 4, [colorKF, opacityKF]);
    const mixer = new THREE.AnimationMixer(animationGroup);

    const clipAction = mixer.clipAction(clip);
    clipAction.setDuration(4);
    clipAction.play();
   
    /* ----------------------------- animation frame ---------------------------- */
    const clock = new THREE.Clock();
    function animate() {
      requestAnimationFrame(animate);
      scene.traverse(darkenNonBloomed);
      composer.render();
      scene.traverse(restoreMaterial);
      finalComposer.render();
     
      TWEEN.update();
      controls.dampingFactor=.5
      controls.enableDamping=true
      controls.keyPanSpeed=230
      controls.update();
      const delta = clock.getDelta();

      if (mixer) {
        mixer.update(delta);
      }
    }
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.minPolarAngle = 0; // radians
    controls.maxPolarAngle = Math.PI / 2.1; // radians
   controls.target=new THREE.Vector3(0,0,0)
    controls.update();
     /* ---------------------------- animation testing --------------------------- */
     Animations.LightAnimation(torusArray);
     Animations.CameraAnimation(controls)
    animate();
  }, []);

  return (
    <>
      <div className="canvas-container">
        {" "}
        <canvas className="canvas"></canvas>
      </div>
    </>
  );
}

export default Scene;
