import React from 'react'
import Scene from '../Components/Scene'

function Home() {
  return (
 <>
 <Scene/>
 </>
  )
}

export default Home